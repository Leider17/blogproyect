
<div>

    <nav>
        <a href="{{ route('index' )}}">
        <div class="logo">
        <img src="{{ asset('imagenes/logo.png') }}" alt="logo">
        <h1>vision360</h1>
        </div>
        </a>
        <div class="button"><a  href="{{ route('register') }}">Registrarse</a></div>
        <div class="button"><a href="{{ route('login') }}">Login</a></div>
        
    </nav>
    <div class="categories">