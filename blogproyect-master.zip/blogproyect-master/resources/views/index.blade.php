@extends('layouts.app')
@include('layouts._partials.header')
@section('title','VISION360')

@section('content')
<livewire:blogs>
@endsection
