@extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('la pagina a la que intenta acceder no existe'))
